# abuse
> World's First Profanity Library.
